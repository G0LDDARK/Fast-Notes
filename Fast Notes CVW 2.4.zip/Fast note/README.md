# Fast Notes
## Instalation

### Automitique
<p>
Installation par le Chrome Web Store : https://chrome.google.com/webstore/detail/fast-notes/gaedllkcnakfllaocbfbiebmnpnhonig/related?hl=fr&authuser=1
</p>

### Manuelle
<p>
1. Téléchargez et extraire le fichier zip depuis Github<br>
2. Activez le mode développeur des extensions "chrome://extensions/" <br>
3. Cliquez sur « Load unpacked » ou « Charger extension non empaquetée » <br>
4. Choisir le dossier ou se trouve le zip extrait, et voilà! <br>
</p>

## Utilisation
<p>
Cliquez sur l'icone de l'extention <br>
</p>

### 07/11/23 Version 2.4

